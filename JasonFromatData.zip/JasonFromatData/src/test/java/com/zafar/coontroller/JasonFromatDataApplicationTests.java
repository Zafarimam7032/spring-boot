package com.zafar.coontroller;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JasonFromatDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
